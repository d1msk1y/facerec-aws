import { RekognitionClient, RecognizeCelebritiesCommand } from "@aws-sdk/client-rekognition";
class RekognitionAdapter {
    constructor(region) {
        this.client = new RekognitionClient({ region });
    }
    async recognizeCelebrity(imageBytes) {
        const command = new RecognizeCelebritiesCommand({
            Image: { Bytes: imageBytes }
        });
        const response = await this.client.send(command);
        if (response.CelebrityFaces && response.CelebrityFaces.length > 0) {
            // Get the match with the highest confidence
            const topMatch = response.CelebrityFaces.reduce((prev, current) => (prev.MatchConfidence ?? 0) > (current.MatchConfidence ?? 0) ? prev : current);
            return {
                Name: topMatch.Name || "Unknown",
                MatchConfidence: topMatch.MatchConfidence || 0
            };
        }
        return null;
    }
}
export default RekognitionAdapter;

import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
class S3Adapter {
    constructor(region) {
        this.client = new S3Client({ region });
    }
    async retrieveImage(bucket, key) {
        const command = new GetObjectCommand({ Bucket: bucket, Key: key });
        const response = await this.client.send(command);
        if (!response.Body) {
            throw new Error(`Empty body for object ${key} in bucket ${bucket}`);
        }
        return this.streamToBuffer(response.Body);
    }
    async saveResult(bucket, key, data) {
        const command = new PutObjectCommand({
            Bucket: bucket,
            Key: key,
            Body: JSON.stringify(data, null, 2),
            ContentType: "application/json"
        });
        await this.client.send(command);
    }
    async streamToBuffer(stream) {
        return new Promise((resolve, reject) => {
            const chunks = [];
            stream.on("data", (chunk) => chunks.push(chunk));
            stream.on("error", reject);
            stream.on("end", () => resolve(Buffer.concat(chunks)));
        });
    }
}
export default S3Adapter;
